import React from "react";
import ReactDOM from "react-dom";
import axios from 'axios';
import {
  Header, Table, Input,
  Container, Rating, Segment,Button, Icon, Form
} from 'semantic-ui-react'

import "./style.css";

class IncorporationForm extends React.Component {
  constructor() {
    super();
    this.state = {


      shareholders: [{ name: "" }],
      urlList: [{ url: "" }],
      responseData: [],
    };
  }



  handleShareholderNameChange = idx => evt => {
    const newShareholders = this.state.urlList.map((shareholder, sidx) => {
      if (idx !== sidx) return shareholder;
      return { ...shareholder, url: evt.target.value };
    });

    this.setState({ urlList: newShareholders });
  };

  handleSubmit = evt => {
    const { url, urlList } = this.state;
    console.log(urlList);

    let plus5 = urlList.map((val, i, arr) => {
      return val.url;
    });
    console.log(plus5);

    axios.post('http://localhost:8080/scrapeRSS', plus5).then((respon) => {
      console.log(respon);
      this.setState({ responseData: respon.data });

      console.log(this.state.responseData, "fgf");
    }).catch((rr) => {
      console.log(rr);
    });

    // fetch('http://localhost:8080/scrapeRSS', {
    //   method: 'POST',
    //   headers:{'content-type': 'application/json'},
    //   body:JSON
    // }).then(res => {
    //        console.log(res);
    //       });

    //alert(`Incorporated: ${url} with ${urlList.length} shareholders`);
  };

  handleAddShareholder = () => {
    this.setState({
      urlList: this.state.urlList.concat([{ url: "" }])
    });
  };

  handleRemoveShareholder = idx => () => {
    this.setState({
      urlList: this.state.urlList.filter((s, sidx) => idx !== sidx)
    });
  };

  render() {
    const { responseData } = this.state;

    return (
      <Segment>

      
        <Container>
          {this.state.urlList.map((data, idx) => (
            <div className="shareholder">
              <Input
                icon='copy'
                style={{ width: 800 }}
                onChange={this.handleShareholderNameChange(idx)}
                value={data.url}
                labelPosition='right'
                placeholder={`Enter Link... #${idx + 1}`}
              />
            
              <Button icon='minus' onClick={this.handleRemoveShareholder(idx)} />
             
            </div>
          ))}

          <div>
            <br>
            </br>
            <Button onClick={this.handleAddShareholder} icon labelPosition='left'>
              <Icon name='plus' />
              Add
    </Button>
            <Button onClick={(ev) => {
              this.handleSubmit(ev)
            }} icon labelPosition='right'>
              Get
      <Icon name='right arrow' />
            </Button>
          </div>
          {/* <button
          type="button"
          onClick={this.handleAddShareholder}
          className="small"
        >
        Add
        </button>
        <button onClick={(ev)=>{
          this.handleSubmit(ev)
        }}>Get Data</button> */}

          <Table celled striped>

            {responseData.map(e => {
              return (
               <Table celled striped>
                  <Table.Header>
                    <Table.Row>
                      <Table.HeaderCell singleLine>Author</Table.HeaderCell>
                      <Table.HeaderCell>Title</Table.HeaderCell>
                      <Table.HeaderCell>Date</Table.HeaderCell>
                      <Table.HeaderCell>LINK</Table.HeaderCell>

                    </Table.Row>
                  </Table.Header>

                  <Table.Body>


                    {e.map(es => {
                      return (
                        <Table.Row>
                          <Table.Cell>{es.author}</Table.Cell>
                          <Table.Cell>{es.title}</Table.Cell>
                          <Table.Cell>{es.date}</Table.Cell>
                          <Table.Cell>{es.link}</Table.Cell>

                        </Table.Row>

                      );
                    })}

                  </Table.Body>
               </Table>


              );
            })}

          </Table>


        </Container>


        </Segment>
    );
  }
}

const rootElement = document.getElementById("root");
ReactDOM.render(<IncorporationForm />, rootElement);

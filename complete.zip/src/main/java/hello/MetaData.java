package hello;

public class MetaData {

	private String author;
	private String title;
	private String date;
	private String link;

	public MetaData(String author, String title, String date, String link) {
		this.author = author;
		this.title = title;
		this.date = date;
		this.link = link;
	}

	public String getAuthor() {
		return author;
	}

	public String getTitle() {
		return title;
	}

	public String getDate() {
		return date;
	}

	public String getLink() {
		return link;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public void setLink(String link) {
		this.link = link;
	}
}

package hello;

import com.sun.syndication.feed.synd.SyndEntry;
import com.sun.syndication.feed.synd.SyndFeed;
import com.sun.syndication.io.SyndFeedInput;
import com.sun.syndication.io.XmlReader;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class RSSFeedScraper {

	// Loop over all the URLs and call the scraping function
	public static List<List<MetaData>> ScrapeAllFeeds(String[] urls) {
		List<List<MetaData>> finalResult = new ArrayList<List<MetaData>>();
		List<MetaData> resultArray = new ArrayList<MetaData>();
		for (String url : urls) {
			resultArray = ScrapeFeed(url);
			finalResult.add(resultArray);
		}
		return finalResult;
	}

	// Get one url and extract the metadata from the RSS feed
	public static List<MetaData> ScrapeFeed(String url) {
		List<MetaData> resultArray = new ArrayList<MetaData>();

		try {
			URL feedUrl = new URL(url);

			SyndFeedInput input = new SyndFeedInput();
			SyndFeed feed = input.build(new XmlReader(feedUrl));

			// Get the entry items
			for (SyndEntry entry : (List<SyndEntry>) feed.getEntries()) {
				MetaData dataEntry = new MetaData(entry.getAuthor(), entry.getTitle(),
						entry.getPublishedDate().toString(), entry.getLink());
				resultArray.add(dataEntry);
			}
		} catch (Exception ex) {
			System.out.println("Error: " + ex.getMessage());
		}
		return resultArray;
	}
}

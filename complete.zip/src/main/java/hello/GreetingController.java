package hello;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(value="*")
@RestController
public class GreetingController {

	@RequestMapping("/greeting") 
	public MetaData greeting(@RequestParam(value="name", defaultValue="World") String name) {
		return new MetaData("hi", "bye", "h","d");
	}
	
    @PostMapping("/scrapeRSS")
    public List<List<MetaData>> search(@RequestBody List<String> body){
    	
        return RSSFeedScraper.ScrapeAllFeeds(GetStringArray(body));
    }
    
    public static String[] GetStringArray(List<String> arr) 
    { 
  
        // declaration and initialise String Array 
        String str[] = new String[arr.size()]; 
  
        // ArrayList to Array Conversion 
        for (int j = 0; j < arr.size(); j++) { 
  
            // Assign each value to String array 
            str[j] = arr.get(j); 
        } 
  
        return str; 
    } 
    
}
